<?php
	mysql_connect("localhost", "root", "") or die("Koneksi Gagal!");
	mysql_select_db("perpus_php") or die("Database tidak ada");
	#echo "Koneksi Sukses";
?>